The programs in this directory are protected under the GNU General Public 
License (GPL: http://www.gnu.org/licenses/gpl.txt) and have been included 
for the convenience of our users. The programs are not an integral part 
of the GAMS system. The programs can also be downloaded freely from a 
number of sites, specifically, we included the binaries from 
http://www.cygwin.com/ based on Cygwin DLL release version 1.5.

If requested by one of our users, we will provide the source code of the
above programs on some electronic media for a modest charge to cover the
cost of media and handling according to the above GNU GPL.