% run this Matlab batch file from Windows as
% matlab -r r_batch -logfile r_batch.log -nosplash

r1
r2
rfull
rsparse
exit
