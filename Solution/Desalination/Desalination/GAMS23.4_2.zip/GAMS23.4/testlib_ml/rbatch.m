% run this Matlab batch file from Windows as
% matlab -r rbatch -logfile rbatch.log -nosplash

read1
read2
read3
read4
read5
rtrns
exit
