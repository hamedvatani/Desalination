% run this Matlab batch file from Windows as
% matlab -r w_batch -logfile w_batch.log -nosplash

writeset
writepar
exit
