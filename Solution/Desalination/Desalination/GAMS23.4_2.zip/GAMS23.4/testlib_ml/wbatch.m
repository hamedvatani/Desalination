% run this Matlab batch file from Windows as
% matlab -r wbatch -logfile wbatch.log -nosplash

write1
write2
write3
write4
exit
